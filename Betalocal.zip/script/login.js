//Three functions to show three different forms
function midwives_form(){
	$(document).ready(function(){
				$("#forms").load('login/midwiveForm.html');
		});
}

function reception_form(){
	$(document).ready(function(){
				$("#forms").load('login/receptionForm.html');
		});
}

function adminstration_form(){
	$(document).ready(function(){
				$("#forms").load('login/adminstrationForm.html');
		});
}

