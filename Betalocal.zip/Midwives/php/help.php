
<div id="container">
<div class="start" >



	<h1>Prospect Palms</h1>
	<p>Private Maternity Hospital</p>
	<h4>Appointment Session</h4>
	<p> Please note session usage is being monitored. All past appointment data will be deleted as soon as another date is assigned for the chosen patient.
	All users should stay within their access acoounts, any attempt to enter an account which is not yours will result in the extermination of your account.
If you are to encounter any problem within the application or in the web browser please follow the three steps below.</p>
<div id="flex-row">
<div  class="help-cards">Check Network availability</div>
<div  class="help-cards">Contact Network Adminstrator</div>
<div  class="help-cards">Reload Page</div>
</div>

</div>
</div>
